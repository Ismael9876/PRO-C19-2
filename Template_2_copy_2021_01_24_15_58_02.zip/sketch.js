var PLAY = 1;
var END = 0;
var gameState = PLAY;
var player,player_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score=0;

function preload(){

  backgroundImage = loadImage("jungle.jpg")
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
player = createSprite(50,316,20,50);
player.addAnimation("running", monkey_running);
player.scale = 0.1;

background=createSprite(300,100,400,100);
  background.addImage(backgroundImage); 
  background.scale=1.1; 
  background. x= background.width/9;
  background.velocityX =-2.2;
  
  
 


  
  
invisibleGround = createSprite(600,350,1500,10);
invisibleGround.visible=false
  
obstaclesGroup = new Group();

FoodGroup = new Group();
  
bananasGroup = new Group();

}


function draw() {


//text("Score: "+ score, 500,50);
//score = score + Math.round(getFrameRate()/60);
    
if(keyDown("space")) {
player.velocityY = -10;
}
  
  player.velocityY = player.velocityY + 0.8

  spawnBananas();
  spawnObstacles();
  
  player.collide(invisibleGround);

if(obstaclesGroup.isTouching(player))
{ player.scale=0.08; score=score-1; }

  
  //if(obstaclesGroup.isTouching(player)){ player.scale=0.08;}
  
  if(bananasGroup.isTouching(player))
  { bananasGroup.destroyEach(); score = score + 2;}
  
  //if (obstaclesGroup.isTouching(player)){
  //    gameState=END;
  //}

  
  
  if (background.x < 0)
  { background.x = background.width/2; 
  }
switch(score){ 
    case 10: player.scale=0.12;
              break;
    case 20: player.scale=0.14; 
              break;
    case 30: player.scale=0.16;
              break;
    case 40: player.scale=0.18;
              break; 
    default: break; }

 
  
  
drawSprites();
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: "+ score, 300, 50);
}



function spawnBananas() {
  //write code here to spawn the clouds
  if (frameCount % 60 === 10) {
    banana = createSprite(600,200,1,50);
    banana.y = Math.round(random(40,150));
    banana.addImage(bananaImage);
    banana.scale = 0.1;
    banana.velocityX = -5;
    
     //assign lifetime to the variable
    banana.lifetime = 134;
    
    //adjust the depth
    banana.depth = player.depth;
    player.depth = player.depth + 1;
    
    //adding cloud to the group
   bananasGroup.add(banana);
  }
  
}
function spawnObstacles() {
  if(frameCount % 400 === 0) {
    obstacle = createSprite(500,315,60,90);
    obstacle.velocityX = -9
    
obstacle.addImage(obstaceImage)
obstacle.scale=0.2
obstacle.lifetime = 100
     obstaclesGroup.add(obstacle);
  }
}



